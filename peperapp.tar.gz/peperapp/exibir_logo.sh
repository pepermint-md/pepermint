#!/bin/bash

# Função para exibir a logo do Peppermint-MD
display_logo() {
    echo "######   ########   ########   ########  ########   #######   ##     ##"
    echo "##    ##  ##     ##  ##     ##  ##        ##        ##     ##  ##     ##"
    echo "##        ##     ##  ##     ##  ##        ##        ##     ##  ##     ##"
    echo " ######   ########   ########   ######    ######    ##     ##  ##     ##"
    echo "      ##  ##   ##    ##   ##    ##        ##        ##     ##  ##     ##"
    echo "##    ##  ##    ##   ##    ##   ##        ##        ##     ##  ##     ##"
    echo " ######   ##     ##  ##     ##  ########  ########   #######    #######"
}

# Função para exibir as equipes
display_teams() {
    echo "Equipe EDXLinux"
    echo "Equipe FostonLinux"
}

# Limpar a tela
clear

# Exibir a logo
display_logo

# Exibir as equipes
echo ""
display_teams

# Manter o terminal aberto até que uma tecla seja pressionada
read -n 1 -s -r -p "Pressione qualquer tecla para sair..."


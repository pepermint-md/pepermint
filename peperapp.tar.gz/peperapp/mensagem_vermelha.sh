#!/bin/bash

# Definir a cor vermelha
RED='\033[0;31m'
# Resetar cor
NC='\033[0m' # No Color

# Mensagem a ser exibida
MESSAGE="Pepermint-md com a equipe edxlinux e fostonlinux: Linux, a tecnologia do futuro"

# Exibir a mensagem em letras vermelhas
echo -e "${RED}${MESSAGE}${NC}"


#!/bin/bash

# Atualizar a lista de pacotes
echo "Atualizando a lista de pacotes..."
sudo apt update

# Instalar programas
echo "Instalando programas..."

# Lista de programas
programs=(
    "vim"
    "curl"
    "git"
    "htop"
    "gimp"
    "vlc"
)

# Loop para instalar cada programa
for program in "${programs[@]}"; do
    echo "Instalando $program..."
    sudo apt install -y "$program"
done

echo "Instalação concluída!"
echo "a equipe pepermint-md edxlinux e fostonlinux agradecem"
